export const receiveResponse = (response:any) => {
	return {
		type: 'RESPONSE_RECEIVED',
		response
	};
};

export const buildDataMap = (data:any) => {
	return {
		type: 'DATA_MAP_BUILDED',
		data
	};
};

export const treeIsReady = (data:any) => {
	return {
		type: 'COMPONENTS_TREE_IS_READY',
		data
	};
};

export const componentsValidationFinish = () => {
	return {
		type: 'COMPONENTS_VALIDATION_FINISHED'
	};
};

export const componentsValidationFailed = (error:any) => {
	return {
		type: 'COMPONENTS_VALIDATION_FAILED',
		error
	};
};



let initialState = {
	response: null,
	error: null,
	data: null,
	nodes: null
};

export default function(state = initialState, action:any) {
	switch (action.type) {
	case 'RESPONSE_RECEIVED':
		return {
			...state,
			response: action.response
		};
	case 'COMPONENTS_VALIDATION_FAILED':
		return{
			...state,
			error:action.error
		}
	case 'DATA_MAP_BUILDED': 
		return{
			...state,
			data:action.data
		}
	case 'COMPONENTS_TREE_IS_READY':
			return{
				...state,
				nodes:action.data
			}
	default:
		return state;
	}
}
