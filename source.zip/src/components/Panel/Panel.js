import React, { Component } from 'react';
import TreeCreator from '../../modules/render';





class Panel extends Component {

	static types = {
		layoutType: {
			type: 'string',
			contract: 'required',
			posValues: [
				'fullScreen',
				'doubleCardLefted',
				'doubleCardRighted',
				'tripleCards'
			]
		}
	};

	areas = {
		fullScreen: {
			display: 'grid',
			gridTemplateAreas: `"area_0"`,
			gridTemplateColumns: '1fr',
			gridTemplateRows: '1fr'
		},
		doubleCardLefted: {
			display: 'grid',
			gridTemplateAreas: `"area_0 area_1"`,
			gridTemplateColumns: '1fr 2fr',
			gridTemplateRows: '1fr'
		},
		doubleCardRighted: {
			display: 'grid',
			gridTemplateAreas: `"area_0 area_1"`,
			gridTemplateColumns: '2fr 1fr',
			gridTemplateRows: '1fr'
		},
		tripleCards: {
			display: 'grid',
			gridTemplateAreas: `"area_0 area_1 area_2"`,
			gridTemplateColumns: '1fr 1fr 1fr',
			gridTemplateRows: '1fr'
		}
	}


	componentWillMount() {

	}

	render () {
		return (
			<div style={{
				backgroundColor: '#eeeeee',
				borderRadius: 50,
				flex: 1,
				boxSizing: 'border-box',
				margin: '2rem',
				...this.areas[this.props.properties.layoutType.value]
			}}>
				{
					!!this.props.nodes && this.props.nodes.map( (node, i) => {
						return(
							<div key={i} style={{display: 'flex', gridArea: `area_${i}`}}>
							<TreeCreator  nodes={node} />
							</div>
						)
					})
				}
			</div>
		)
	}
}
export default Panel;
