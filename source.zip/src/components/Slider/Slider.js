import React, { Component } from 'react';
import { connect } from 'react-redux';

class Slider extends Component {


	static types = {
		currentValue: {
			type: 'string',
			contract: 'required'
		},
		maxValue: {
			type: 'string',
			contract: 'required'
		},
		containerColor: {
			type: 'string',
			contract: 'optional'
		},
		size: {
			type: 'string',
			contract: 'optional'
		}
	};


	fonts = {
		'small': '10px',
		'medium': '14px',
		'large': '22px'
	}


	render () {
		console.log(true);
		return (
			<div style={{
				position: 'relative',
				borderRadius: '5px',
				width: '200px',
				height: '10px',
				background: (this.props.properties.containerColor) ? this.props.properties.containerColor.value : 'white'
			}}>
				<div style={{
					position: 'absolute',
					background: 'gray',
					height:'10px',
					width: `${(this.props.properties.currentValue.value / this.props.properties.maxValue.value) * 100}%`
				}}></div>
			</div>
		)
	}
}

function mapStateToProps(store) {
	return {
	};
}

function mapDispatchToProps(dispatch) {
	return {

	};
}

export default connect(mapStateToProps, mapDispatchToProps)(Slider);
