import React, { Component } from 'react';
import { connect } from 'react-redux';

class NumScore extends Component {


	static types = {
		currentValue: {
			type: 'string',
			contract: 'required'
		},
		maxValue: {
			type: 'string',
			contract: 'required'
		},
		currentValueColor: {
			type: 'string',
			contract: 'optional'
		},
		haveBox: {
			type: 'boolean',
			contract: 'optional'
		},
		fontSize: {
			type: 'string',
			contract: 'optional'
		}
	};


	fonts = {
		'small': '10px',
		'medium': '14px',
		'large': '22px'
	}


	render () {
		return (
			<div style={{
				borderRadius: '10px',
				fontSize: (this.props.properties.fontSize)  ? this.fonts[this.props.properties.fontSize.value] : '14px',
				background: (this.props.properties.haveBox)  ? '#333'  : 'none',
				display: 'inline-block',
				padding: '10px'
			}}>
				<span style={{
					color: (this.props.properties.currentValueColor) ? this.props.properties.currentValueColor.value : '#000000'
				}}>
					{this.props.properties.currentValue.value}
				</span>
				<span style={{
					color: '#bbbbbb'
				}}> / {this.props.properties.maxValue.value} </span>
			</div>
		)
	}
}

function mapStateToProps(store) {
	return {
	};
}

function mapDispatchToProps(dispatch) {
	return {

	};
}

export default connect(mapStateToProps, mapDispatchToProps)(NumScore);
