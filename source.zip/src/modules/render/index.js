import React from 'react';
import * as Components from '../../components';


const createComponent = function (node) {
	if (Components[node.name]) {
		let properties = {
			properties: node.properties,
			nodes: node.childComponents
		};

		return React.createElement(Components[node.name], properties);
	}
};

function MyComponent(props) {
	return (
		<>
			{createComponent(props.nodes)}
		</>
	)
}

export default MyComponent;