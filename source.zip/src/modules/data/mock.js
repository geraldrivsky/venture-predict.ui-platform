module.exports = {
    MetaData: {

    },
    Data: {
        current_value: 2,
        max_value: 5
    },
    Tree: {
        name: 'Panel',
        childComponents: [
            {
                name: 'Card',
                childComponents : [
                    {
                        name: 'NumScore',
                        properties: {
                            currentValue: {
                                value: 'current_value',
                                type: 'ref'
                            },
                            maxValue: {
                                value: 'max_value',
                                type: 'ref'
                            },
                            currentValueColor: {
                                value: 'orange',
                                type: 'string'
                            },
                            haveBox: {
                                value: true,
                                type: 'boolean'
                            },
                            fontSize: {
                                value: 'large',
                                type: 'string'
                            }
                        }
                    }
                ],
                properties: {
                    title: {
                        value: 'Card 1 name',
                        type: 'string'
                    }
                }
            },
            {
                name: 'Card',
                properties: {
                    title: {
                        value: 'Card 2 name',
                        type: 'string'
                    }
                },
                childComponents: [
                    {
                        name: 'Slider',
                        properties: {
                            currentValue: {
                                value: 'current_value',
                                type: 'ref'
                            },
                            maxValue: {
                                value: 'max_value',
                                type: 'ref'
                            },
                            containerColor: {
                                value: 'orange',
                                type: 'string'
                            },
                            size: {
                                value: 'large',
                                type: 'boolean'
                            }  
                        }
                    }
                ]
            }
        ],
        properties: {
            layoutType: {
                value: 'doubleCardLefted',
                type: 'string'
            }
        }
    }
}