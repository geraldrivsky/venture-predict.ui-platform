import React, {Component} from 'react';
import { connect } from 'react-redux';
import { getData } from './modules/data/data.service';
import TreeCreator from './modules/render';



class App extends Component<any, any> {
  constructor(props:any) {
		super(props);
		this.state = {
			mode: 'default'
		};
  }

  componentDidMount(){
    this.props.getData('mock');
  }
  
  render(){
    if (this.props.error) {
			return (
				<div style={{background: 'rgba(255,0,0,0.1)', padding: '10px'}}>
          <h5>{this.props.error.message}</h5>
          <pre style={{background: 'rgba(255,0,0,0.1)', padding: '10px'}}>{this.props.error.description}</pre>
        </div>
			)
		}
    return(
      // <TreeCreator nodes={this.props.page}/>
      <>
        {
          (this.props.nodes)
          ?
          <TreeCreator nodes={this.props.nodes}/>
          :
          <span>Ожидание...</span>
        }
      </>
    )
  }
}

function mapStateToProps(store:any) {
	return {
    error: store.MainState.error,
    nodes: store.MainState.nodes
	};
}

function mapDispatchToProps(dispatch:any) {
	return {
    getData: (query:any) => {
      dispatch( getData(query) );
    }
	};
}

export default connect(mapStateToProps, mapDispatchToProps)(App);
