import {default as Mock} from './mock';

class DataApi {
	static getData(query:any){
		return Promise.resolve(Mock);
		// return fetch(`some_endpoint_root`, {
		// 	method: 'GET',
		// 	credentials: 'include'
		// })
		// 	.then(response => response.json())
		// 	.then(handleTokenErrors)
		// 	.catch(error => {
		// 		throw error;
		// 	});
	}
}

export default DataApi;
