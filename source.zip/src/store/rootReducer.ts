import { combineReducers } from 'redux';
import MainState from '../modules/data/data.reducer';

const rootReducer = combineReducers({
    MainState
});

export default rootReducer;
