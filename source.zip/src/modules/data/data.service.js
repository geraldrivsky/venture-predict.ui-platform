import DataApi from './data.api';
import * as DataReducer from './data.reducer';
import * as Components from '../../components';


class Error{
	message;
	description;
    constructor(message, description){
        this.message = message;
        this.description = description;
    }
}

const validateIt = (data)=>{
	let error = null;
	

	function loop(node){
		let ControlName = node.name,
			Control = Components[ControlName];

		// Контрола нет в библиотеке. С сервера пришел не валидный json.
		if(Control === undefined){
			error = new Error(
				`Component with name: «‎${ControlName}» is not existed in the component library`,
				JSON.stringify(node, null, 3)
			)
			return false;
		}

		// Не валидное создание контрола на клиенте. Указать тип.
		if (!Control.types) {
			error = new Error(
				`Invalid component's creation («‎${ControlName}»). Add property types.`,
				`${ControlName}`
			)
			return false;
		}

		// Контрол из дерева не содержит обязательных параметров.
		if (Control.types) {
			for (let type in Control.types ){
				if(
					(Control.types[type].contract === 'required' && !node.properties[type])
					|| (Control.types[type].contract === 'required' && Control.types[type].posValues && Control.types[type].posValues.indexOf(node.properties[type].value) < 0)
				){
					error = new Error(
						`Component «‎${ControlName}» hasn't required properties`,
						`Required properties:\n${Object.keys(Control.types)}: ${Control.types[type].posValues}\n\nNode:\n${JSON.stringify(node, null, 3)}`
					)
					return false;
				}
			}
		}

		// Не удается смапить ref на данные. Не хватает данных.
		if (node.properties) {
			let e = false;

			Object.keys(node.properties).forEach((key) => {
				if (
					node.properties[key].type === 'ref'
					&& !data.Data[node.properties[key].value]
				){
					e = true;
				}
			});

			if (e) {
				error = new Error(`Component «‎${ControlName}» has empty reference`,
					`${JSON.stringify(node, null, 3)}`
				);

				return false;
			}
		}

		if (node.childComponents && node.childComponents.length) node.childComponents.forEach((n) => loop(n));
	}



	loop(data.Tree);
	return error;
}

const resolveDataRefs = (tree, data)=>{

	function loop(node){
		if (node.properties) {
			Object.keys(node.properties).forEach((key) => {
				if (
					node.properties[key].type === 'ref'
					&& data[node.properties[key].value]
				){
					node.properties[key].value = data[node.properties[key].value]
				}
			});
		}
		if (node.childComponents && node.childComponents.length) node.childComponents.forEach((n) => loop(n));
	}
	loop(tree);
	return tree;
}

export const getData = (query) => (dispatch) => {
	return DataApi.getData(query)
		.then(response => {
			if (response) {
				// 1 Дата пришла с сервера
				dispatch(DataReducer.receiveResponse(response));
				// 1 Валидируем json
				let validResult = validateIt(response);
				
				if(!validResult){
					// Сигнрализируем, что данные валидны
					dispatch(DataReducer.componentsValidationFinish());
					// Резолвим ссылки типа ref на реальные данныее
					dispatch(DataReducer.buildDataMap(response.Data));
					// Кладем дерево нодов уже с реальными данными
					dispatch(DataReducer.treeIsReady( resolveDataRefs(response.Tree, response.Data)) );
				}else{
					// Если есть ошибка, диспатчим ее
					dispatch(DataReducer.componentsValidationFailed(validResult));
				}
			}
		})
		.catch(error => {
			throw error;
		});
};
