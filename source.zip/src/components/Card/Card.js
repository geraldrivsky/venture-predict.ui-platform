import React, { Component } from 'react';
import TreeCreator from '../../modules/render';





class Card extends Component {


	static types = {
		title: {
			type: 'string',
			contract: 'required'
		}
	};


	componentWillMount() {

	}

	render () {
		return (
			<div style={{
				backgroundColor: '#ddd',
				flex: 1,
				boxSizing: 'border-box',
				margin: '2rem',
				borderRadius: 50,
			}}>
				<h2>{this.props.properties.title.value}</h2>
				{
					!!this.props.nodes && this.props.nodes.map( (node, i) => {
						return(
							<TreeCreator key={i} nodes={node} />
						)
					})
				}
			</div>
		)
	}
}
export default Card;
